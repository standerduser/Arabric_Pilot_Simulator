# Flight Simulator Game

## Overview

This is a 3D flight simulator game built with React Three Fiber, Express.js, and TypeScript. The application features a 3D airplane flying through a city environment with landing challenges, collision detection, and immersive audio. Players control an airplane using WASD keys with physics-based flight mechanics, attempting to land at designated zones while avoiding buildings and managing fuel consumption.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The frontend is built using **React 18** with **Three.js/React Three Fiber** for 3D rendering and **Tailwind CSS** with **Radix UI** components for the user interface. The application follows a component-based architecture with:

- **3D Scene Management**: React Three Fiber handles the 3D rendering pipeline with custom components for the airplane, city environment, camera controls, and visual effects
- **State Management**: Zustand stores manage game state (flight mechanics, audio controls, game phases) with reactive subscriptions
- **Physics Engine**: Custom physics implementation for realistic flight dynamics including gravity, acceleration, and collision detection
- **Asset Loading**: Support for GLTF/GLB 3D models, audio files, and GLSL shaders through Vite plugins

The choice of React Three Fiber over vanilla Three.js provides better React integration and declarative 3D scene composition, while Zustand offers simpler state management compared to Redux for this gaming use case.

### Backend Architecture

The backend uses **Express.js** with TypeScript, following a minimal REST API pattern. The server architecture includes:

- **Route Registration**: Centralized route management through a registration system in `server/routes.ts`
- **Storage Interface**: Abstract storage layer with in-memory implementation for user data, designed for easy database swapping
- **Development Setup**: Vite integration for hot module replacement during development
- **Build Process**: ESBuild bundling for production deployment with proper Node.js targeting

The backend is intentionally lightweight since this is primarily a client-side game, with the server mainly serving the React application and providing potential for future multiplayer features.

### Data Storage Solutions

The application uses **Drizzle ORM** with PostgreSQL configuration for future database needs, though currently implements in-memory storage:

- **Database Schema**: User table defined in `shared/schema.ts` with Zod validation
- **Storage Abstraction**: Interface-based storage layer allowing seamless transition from memory to database storage
- **Migration Support**: Drizzle migrations configured for schema evolution

The choice of Drizzle provides type-safe database operations and excellent TypeScript integration, while the storage interface pattern allows starting with memory storage and upgrading to persistent storage when needed.

### Authentication and Authorization

Currently implements a basic user schema foundation with username/password fields, prepared for future authentication implementation. The shared schema approach ensures type consistency between frontend and backend for user data handling.

## External Dependencies

### 3D Graphics and Gaming
- **@react-three/fiber**: Core Three.js React integration for 3D scene management
- **@react-three/drei**: Additional helpers and controls for enhanced 3D experiences  
- **@react-three/postprocessing**: Visual effects and post-processing pipeline
- **three**: Underlying 3D graphics library for mathematics and rendering

### UI Framework
- **@radix-ui/***: Complete accessible component library for consistent UI patterns
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Component variant management for design systems

### State Management and Data
- **zustand**: Lightweight state management for game and audio state
- **@tanstack/react-query**: Server state management and caching (prepared for future API integration)

### Database and ORM
- **drizzle-orm**: Type-safe ORM for PostgreSQL database operations
- **@neondatabase/serverless**: Serverless PostgreSQL connection for cloud deployment
- **drizzle-kit**: Database migration and schema management tools

### Build Tools and Development
- **vite**: Fast build tool and development server with HMR support
- **tsx**: TypeScript execution for server-side development
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay integration