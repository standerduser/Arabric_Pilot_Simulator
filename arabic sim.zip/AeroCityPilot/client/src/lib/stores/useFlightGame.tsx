import { create } from "zustand";
import * as THREE from "three";

interface FlightGameState {
  // Game state
  gamePhase: "ready" | "playing" | "crashed" | "won";
  
  // Airplane state
  position: THREE.Vector3;
  rotation: THREE.Euler;
  velocity: THREE.Vector3;
  speed: number;
  altitude: number;
  fuel: number;
  
  // Game settings
  showFuel: boolean;
  arabicMode: boolean;
  
  // Landing zones
  landingZones: THREE.Vector3[];
  currentLandingZone: number;
  landingZoneTimer: number;
  
  // Building explosions
  buildingExplosions: Array<{ position: THREE.Vector3; id: string }>;
  
  // Actions
  updatePosition: (newPosition: THREE.Vector3) => void;
  updateRotation: (newRotation: THREE.Euler) => void;
  updateVelocity: (newVelocity: THREE.Vector3) => void;
  updateSpeed: (newSpeed: number) => void;
  updateAltitude: (newAltitude: number) => void;
  consumeFuel: (amount: number) => void;
  toggleFuelDisplay: () => void;
  toggleArabicMode: () => void;
  crash: () => void;
  win: () => void;
  respawn: () => void;
  startGame: () => void;
  generateLandingZones: () => void;
  updateLandingZoneTimer: () => void;
  addBuildingExplosion: (position: THREE.Vector3) => void;
  removeBuildingExplosion: (id: string) => void;
}

// Initial spawn position (safe takeoff area) - face down the runway (positive Z direction)
const SPAWN_POSITION = new THREE.Vector3(0, 2, -12);
const SPAWN_ROTATION = new THREE.Euler(0, 0, 0);

export const useFlightGame = create<FlightGameState>((set, get) => ({
  // Initial state
  gamePhase: "ready",
  position: SPAWN_POSITION.clone(),
  rotation: SPAWN_ROTATION.clone(),
  velocity: new THREE.Vector3(0, 0, 0),
  speed: 0,
  altitude: 2,
  fuel: 100,
  showFuel: true,
  arabicMode: false,
  landingZones: [],
  currentLandingZone: 0,
  landingZoneTimer: 0,
  buildingExplosions: [],
  
  // Actions
  updatePosition: (newPosition) => {
    set({ position: newPosition.clone() });
  },
  
  updateRotation: (newRotation) => {
    set({ rotation: newRotation.clone() });
  },
  
  updateVelocity: (newVelocity) => {
    set({ velocity: newVelocity.clone() });
  },
  
  updateSpeed: (newSpeed) => {
    set({ speed: Math.max(0, newSpeed) });
  },
  
  updateAltitude: (newAltitude) => {
    set({ altitude: Math.max(0, newAltitude) });
  },
  
  consumeFuel: (amount) => {
    set((state) => ({ fuel: Math.max(0, state.fuel - amount) }));
  },
  
  toggleFuelDisplay: () => {
    set((state) => ({ showFuel: !state.showFuel }));
  },
  
  toggleArabicMode: () => {
    set((state) => ({ arabicMode: !state.arabicMode }));
  },
  
  crash: () => {
    console.log("Airplane crashed!");
    set({ gamePhase: "crashed" });
  },
  
  win: () => {
    console.log("Landing successful!");
    set({ gamePhase: "won" });
  },
  
  respawn: () => {
    console.log("Respawning airplane...");
    const { arabicMode } = get();
    set({
      gamePhase: "playing",
      position: SPAWN_POSITION.clone(),
      rotation: SPAWN_ROTATION.clone(),
      velocity: new THREE.Vector3(0, 0, 0),
      speed: 0,
      altitude: 2,
      fuel: arabicMode ? 30 : 100, // Much less fuel in Arabic mode
      landingZoneTimer: 0,
    });
  },
  
  startGame: () => {
    const { generateLandingZones, arabicMode } = get();
    generateLandingZones();
    set({ 
      gamePhase: "playing",
      fuel: arabicMode ? 30 : 100, // Much less fuel in Arabic mode
      landingZoneTimer: 0
    });
  },
  
  generateLandingZones: () => {
    // Generate single airborne landing zone for increased difficulty
    const x = (Math.random() - 0.5) * 60; // Random position in city
    const z = (Math.random() - 0.5) * 60;
    const y = Math.random() * 20 + 10; // Random height between 10-30 meters (mid-air)
    
    // Ensure zone is not too close to spawn
    const distance = Math.sqrt(x * x + z * z);
    if (distance < 25) {
      // If too close, move it further out
      const angle = Math.atan2(z, x);
      const newX = Math.cos(angle) * 30;
      const newZ = Math.sin(angle) * 30;
      const zone = new THREE.Vector3(newX, y, newZ);
      set({ landingZones: [zone], currentLandingZone: 0 });
    } else {
      const zone = new THREE.Vector3(x, y, z);
      set({ landingZones: [zone], currentLandingZone: 0 });
    }
  },
  
  addBuildingExplosion: (position) => {
    const id = Date.now().toString();
    set((state) => ({
      buildingExplosions: [...state.buildingExplosions, { position: position.clone(), id }]
    }));
  },
  
  removeBuildingExplosion: (id) => {
    set((state) => ({
      buildingExplosions: state.buildingExplosions.filter(explosion => explosion.id !== id)
    }));
  },
  
  updateLandingZoneTimer: () => {
    const { arabicMode, landingZoneTimer, generateLandingZones } = get();
    if (arabicMode && landingZoneTimer >= 5) {
      // Change landing zone position every 5 seconds in Arabic mode
      generateLandingZones();
      set({ landingZoneTimer: 0 });
    } else {
      set({ landingZoneTimer: landingZoneTimer + 1 });
    }
  },
}));
