import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface BuildingExplosionProps {
  position: THREE.Vector3;
  onComplete: () => void;
}

export function BuildingExplosion({ position, onComplete }: BuildingExplosionProps) {
  const groupRef = useRef<THREE.Group>(null);
  const particlesRef = useRef<THREE.Points[]>([]);
  const startTime = useRef(Date.now());

  useEffect(() => {
    console.log("Building explosion effect started at position:", position);
    
    // Auto-complete after 2 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 2000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  useFrame(() => {
    if (!groupRef.current) return;

    const elapsed = (Date.now() - startTime.current) / 1000;
    const progress = elapsed / 2; // 2 second duration

    // Animate particles
    particlesRef.current.forEach((particles) => {
      if (particles) {
        const positions = particles.geometry.attributes.position.array as Float32Array;
        const velocities = (particles as any).velocities;
        
        for (let i = 0; i < positions.length; i += 3) {
          positions[i] += velocities[i] * 0.15; // x
          positions[i + 1] += velocities[i + 1] * 0.15; // y
          positions[i + 2] += velocities[i + 2] * 0.15; // z
          
          // Apply gravity to y
          velocities[i + 1] -= 0.03;
        }
        
        particles.geometry.attributes.position.needsUpdate = true;
        
        // Fade out
        if (particles.material instanceof THREE.PointsMaterial) {
          particles.material.opacity = Math.max(0, 1 - progress);
        }
      }
    });
  });

  // Create explosion particles
  const createParticles = (count: number, color: string, spread: number) => {
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Initial position (at explosion center)
      positions[i3] = position.x;
      positions[i3 + 1] = position.y;
      positions[i3 + 2] = position.z;
      
      // Random velocity
      velocities[i3] = (Math.random() - 0.5) * spread;
      velocities[i3 + 1] = Math.random() * spread * 0.7;
      velocities[i3 + 2] = (Math.random() - 0.5) * spread;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color,
      size: 0.8,
      transparent: true,
      opacity: 1,
    });

    const particles = new THREE.Points(geometry, material);
    (particles as any).velocities = velocities;
    
    return particles;
  };

  useEffect(() => {
    if (groupRef.current) {
      // Create different particle systems for building debris
      const debrisParticles = createParticles(40, '#8b4513', 5);
      const dustParticles = createParticles(30, '#a0a0a0', 3);
      const fireParticles = createParticles(25, '#ff4500', 4);

      groupRef.current.add(debrisParticles);
      groupRef.current.add(dustParticles);
      groupRef.current.add(fireParticles);

      particlesRef.current = [debrisParticles, dustParticles, fireParticles];
    }
  }, []);

  return (
    <group ref={groupRef}>
      {/* Central explosion flash */}
      <mesh position={position.toArray()}>
        <sphereGeometry args={[3, 8, 8]} />
        <meshBasicMaterial color="#ff6600" transparent opacity={0.7} />
      </mesh>
      
      {/* Light flash */}
      <pointLight
        position={position.toArray()}
        color="#ff4500"
        intensity={4}
        distance={25}
      />
    </group>
  );
}