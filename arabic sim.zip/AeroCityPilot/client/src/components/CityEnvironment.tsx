import { useTexture } from "@react-three/drei";
import { useMemo } from "react";
import * as THREE from "three";
import { MovingBuildings } from "./MovingBuildings";
import { useFlightGame } from "../lib/stores/useFlightGame";

export function CityEnvironment() {
  const grassTexture = useTexture("/textures/grass.png");
  const asphaltTexture = useTexture("/textures/asphalt.png");
  const arabicMode = useFlightGame((state) => state.arabicMode);

  // Configure texture tiling
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(20, 20);
  
  asphaltTexture.wrapS = asphaltTexture.wrapT = THREE.RepeatWrapping;
  asphaltTexture.repeat.set(5, 20);

  // Generate building positions (memoized to prevent flickering)
  const buildings = useMemo(() => {
    const buildingList = [];
    for (let x = -40; x <= 40; x += 20) {
      for (let z = -40; z <= 40; z += 20) {
        // Skip extended safe takeoff zone (longer runway)
        if (Math.abs(x) < 12 && z >= -20 && z <= 5) continue;
        
        const height = Math.random() * 15 + 10; // Random height between 10-25
        // Fixed color per building to prevent flashing
        const hue = 200 + Math.random() * 40;
        const lightness = 40 + Math.random() * 20;
        buildingList.push({ x, z, height, color: `hsl(${hue}, 30%, ${lightness}%)` });
      }
    }
    return buildingList;
  }, []);

  return (
    <group>
      {/* Ground plane with grass texture */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[200, 200]} />
        <meshLambertMaterial map={grassTexture} />
      </mesh>

      {/* Extended takeoff runway */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, -7.5]}>
        <planeGeometry args={[8, 35]} />
        <meshLambertMaterial map={asphaltTexture} />
      </mesh>

      {/* Runway markings */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, -7.5]}>
        <planeGeometry args={[0.5, 30]} />
        <meshLambertMaterial color="white" />
      </mesh>

      {/* Buildings - static for normal mode, moving for Arabic mode */}
      {arabicMode ? (
        <MovingBuildings />
      ) : (
        buildings.map((building, index) => (
          <group key={index} position={[building.x, building.height / 2, building.z]}>
            <mesh>
              <boxGeometry args={[8, building.height, 8]} />
              <meshLambertMaterial color={building.color} />
            </mesh>
            
            {/* Building windows */}
            {Array.from({ length: Math.floor(building.height / 3) }, (_, floor) => (
              <group key={floor} position={[0, -building.height / 2 + floor * 3 + 1.5, 0]}>
                {/* Front windows */}
                <mesh position={[0, 0, 4.01]}>
                  <planeGeometry args={[6, 1]} />
                  <meshLambertMaterial color="yellow" opacity={0.8} transparent />
                </mesh>
                {/* Back windows */}
                <mesh position={[0, 0, -4.01]} rotation={[0, Math.PI, 0]}>
                  <planeGeometry args={[6, 1]} />
                  <meshLambertMaterial color="yellow" opacity={0.8} transparent />
                </mesh>
                {/* Side windows */}
                <mesh position={[4.01, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
                  <planeGeometry args={[6, 1]} />
                  <meshLambertMaterial color="yellow" opacity={0.8} transparent />
                </mesh>
                <mesh position={[-4.01, 0, 0]} rotation={[0, -Math.PI / 2, 0]}>
                  <planeGeometry args={[6, 1]} />
                  <meshLambertMaterial color="yellow" opacity={0.8} transparent />
                </mesh>
              </group>
            ))}
          </group>
        ))
      )}

      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight
        position={[50, 50, 25]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={100}
        shadow-camera-left={-50}
        shadow-camera-right={50}
        shadow-camera-top={50}
        shadow-camera-bottom={-50}
      />
    </group>
  );
}
