import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFlightGame } from "../lib/stores/useFlightGame";

interface LandingZoneProps {
  position: THREE.Vector3;
  index: number;
  onLanding: () => void;
}

export function LandingZone({ position, index, onLanding }: LandingZoneProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  const airplanePosition = useFlightGame((state) => state.position);
  const airplaneAltitude = useFlightGame((state) => state.altitude);

  useFrame((state) => {
    // Animate the landing zone
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.02;
    }
    if (ringRef.current) {
      ringRef.current.rotation.y -= 0.01;
      // Pulse effect
      const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.1;
      ringRef.current.scale.setScalar(scale);
    }

    // Check for landing - adjusted for airborne zones
    const distance = airplanePosition.distanceTo(position);
    const altitudeDiff = Math.abs(airplanePosition.y - position.y);
    if (distance < 6 && altitudeDiff < 4) {
      console.log(`Landing detected at zone ${index}!`);
      onLanding();
    }
  });

  return (
    <group position={position.toArray()}>
      {/* Landing pad */}
      <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]}>
        <cylinderGeometry args={[4, 4, 0.1, 8]} />
        <meshLambertMaterial color="#00ff00" />
      </mesh>
      
      {/* Outer ring */}
      <mesh ref={ringRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.1, 0]}>
        <ringGeometry args={[4.5, 5, 16]} />
        <meshLambertMaterial color="#00ff00" transparent opacity={0.6} />
      </mesh>
      
      {/* Center marker */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.11, 0]}>
        <cylinderGeometry args={[0.5, 0.5, 0.02, 8]} />
        <meshLambertMaterial color="#ffffff" />
      </mesh>

      {/* Beacon light */}
      <pointLight
        position={[0, 2, 0]}
        color="#00ff00"
        intensity={1}
        distance={10}
      />
    </group>
  );
}
