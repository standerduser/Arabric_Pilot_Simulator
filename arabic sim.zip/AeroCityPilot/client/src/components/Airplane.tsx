import { useRef, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useFlightGame } from "../lib/stores/useFlightGame";

enum Controls {
  forward = 'forward',
  backward = 'backward',
  left = 'left',
  right = 'right',
  boost = 'boost',
  slow = 'slow',
}

interface AirplaneProps {
  onCollision: () => void;
}

export function Airplane({ onCollision }: AirplaneProps) {
  const meshRef = useRef<THREE.Group>(null);
  const [subscribe, getControls] = useKeyboardControls<Controls>();
  const { camera } = useThree();
  
  const {
    position,
    rotation,
    velocity,
    speed,
    altitude,
    fuel,
    gamePhase,
    arabicMode,
    updatePosition,
    updateRotation,
    updateVelocity,
    updateSpeed,
    updateAltitude,
    consumeFuel,
    addBuildingExplosion,
    updateLandingZoneTimer,
  } = useFlightGame();

  // Simple control constants - adjusted for Arabic mode
  const MAX_SPEED = 0.4;
  const MIN_SPEED = 0;
  const ACCELERATION = 0.01;
  const TURN_SPEED = 0.015;
  const VERTICAL_SPEED = 0.15;
  const FUEL_CONSUMPTION = arabicMode ? 0.08 : 0.02; // Much higher fuel consumption in Arabic mode

  useEffect(() => {
    console.log("Airplane initialized");
    
    // Subscribe to control changes for logging
    const unsubscribeForward = subscribe(
      (state) => state.forward,
      (pressed) => console.log("Forward (W):", pressed)
    );
    const unsubscribeBackward = subscribe(
      (state) => state.backward,
      (pressed) => console.log("Backward (S):", pressed)
    );
    const unsubscribeLeft = subscribe(
      (state) => state.left,
      (pressed) => console.log("Left (A):", pressed)
    );
    const unsubscribeRight = subscribe(
      (state) => state.right,
      (pressed) => console.log("Right (D):", pressed)
    );

    return () => {
      unsubscribeForward();
      unsubscribeBackward();
      unsubscribeLeft();
      unsubscribeRight();
    };
  }, [subscribe]);

  useFrame((state, delta) => {
    if (!meshRef.current || gamePhase !== "playing" || fuel <= 0) return;

    const controls = getControls();
    const mesh = meshRef.current;
    
    // Get current state
    let currentSpeed = speed;
    let currentRotation = rotation.clone();
    let currentPosition = position.clone();

    // Simple, direct controls - no confusing physics
    if (controls.forward) {
      // W key - climb up directly
      currentPosition.y += VERTICAL_SPEED * delta * 60;
      currentRotation.x = -0.1; // Slight nose-up visual
    }
    if (controls.backward) {
      // S key - dive down directly
      currentPosition.y -= VERTICAL_SPEED * delta * 60;
      currentRotation.x = 0.1; // Slight nose-down visual
    }
    if (controls.left) {
      // A key - turn left
      currentRotation.y += TURN_SPEED * delta * 60;
    }
    if (controls.right) {
      // D key - turn right
      currentRotation.y -= TURN_SPEED * delta * 60;
    }
    if (controls.boost) {
      // Shift - increase speed only
      currentSpeed = Math.min(currentSpeed + ACCELERATION, MAX_SPEED);
      consumeFuel(FUEL_CONSUMPTION * 1.5);
    }
    if (controls.slow) {
      // Ctrl - decrease speed
      currentSpeed = Math.max(currentSpeed - ACCELERATION, MIN_SPEED);
    }
    
    // Reset pitch when no vertical input
    if (!controls.forward && !controls.backward) {
      currentRotation.x *= 0.9; // Gradually return to level
    }

    // Simple forward movement without complex physics
    if (currentSpeed > 0) {
      const forwardDirection = new THREE.Vector3(0, 0, 1);
      forwardDirection.applyEuler(new THREE.Euler(0, currentRotation.y, 0)); // Only use Y rotation for direction
      forwardDirection.normalize();
      
      // Move forward based on speed
      currentPosition.add(forwardDirection.multiplyScalar(currentSpeed * delta * 60));
    }
    
    // Simple ground collision
    if (currentPosition.y < 1.5) {
      currentPosition.y = 1.5;
    }

    // No need for separate altitude calculation

    // Update mesh transform
    mesh.position.copy(currentPosition);
    mesh.rotation.copy(currentRotation);

    // Update store
    updatePosition(currentPosition);
    updateRotation(currentRotation);
    updateVelocity(new THREE.Vector3(0, 0, 0)); // Simple - no complex velocity
    updateSpeed(currentSpeed);
    updateAltitude(currentPosition.y);

    // Consume fuel based on speed
    if (currentSpeed > 0) {
      consumeFuel(FUEL_CONSUMPTION * delta * 60);
    }
    
    // Update landing zone timer every second in Arabic mode
    if (arabicMode && Math.floor(state.clock.elapsedTime) % 1 === 0) {
      updateLandingZoneTimer();
    }

    // Simple collision detection with buildings (basic check)
    // Buildings are positioned in a grid, check for collision
    const airplaneBox = new THREE.Box3().setFromCenterAndSize(
      currentPosition,
      new THREE.Vector3(2, 1, 4) // Airplane bounding box
    );

    // Check collision with buildings (positioned at regular intervals)
    for (let x = -40; x <= 40; x += 20) {
      for (let z = -40; z <= 40; z += 20) {
        // Skip extended safe takeoff area (longer runway)
        if (Math.abs(x) < 12 && z >= -20 && z <= 5) continue;
        
        const buildingBox = new THREE.Box3().setFromCenterAndSize(
          new THREE.Vector3(x, 10, z),
          new THREE.Vector3(8, 20, 8) // Building bounding box
        );

        if (airplaneBox.intersectsBox(buildingBox)) {
          console.log("Collision detected with building!");
          // Add explosion at building position
          addBuildingExplosion(new THREE.Vector3(x, 10, z));
          onCollision();
          return;
        }
      }
    }
  });

  return (
    <group ref={meshRef} position={position.toArray()} rotation={rotation.toArray()}>
      {/* Airplane body */}
      <mesh>
        <boxGeometry args={[0.5, 0.3, 3]} />
        <meshLambertMaterial color="#4a90e2" />
      </mesh>
      
      {/* Wings */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[4, 0.1, 0.8]} />
        <meshLambertMaterial color="#2c5aa0" />
      </mesh>
      
      {/* Tail */}
      <mesh position={[0, 0.5, -1.2]}>
        <boxGeometry args={[0.1, 1, 0.5]} />
        <meshLambertMaterial color="#2c5aa0" />
      </mesh>
      
      {/* Propeller */}
      <mesh position={[0, 0, 1.6]}>
        <cylinderGeometry args={[0.05, 0.05, 0.2]} />
        <meshLambertMaterial color="#666666" />
      </mesh>
    </group>
  );
}
