import React from "react";
import { useFlightGame } from "../lib/stores/useFlightGame";
import { useKeyboardControls } from "@react-three/drei";

enum Controls {
  forward = 'forward',
  backward = 'backward',
  left = 'left',
  right = 'right',
  boost = 'boost',
  slow = 'slow',
}

export function GameHUD() {
  const {
    speed,
    altitude,
    fuel,
    showFuel,
    gamePhase,
    landingZones,
    arabicMode,
    toggleFuelDisplay,
    toggleArabicMode,
    startGame,
    respawn
  } = useFlightGame();

  const [subscribe, getControls] = useKeyboardControls<Controls>();

  // Handle respawn on R key
  const handleKeyPress = (e: KeyboardEvent) => {
    if (e.key.toLowerCase() === 'r' && gamePhase === "crashed") {
      respawn();
    }
  };

  // Add event listener for R key
  React.useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gamePhase]);

  if (gamePhase === "ready") {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white z-50">
        <div className="text-center p-8 bg-gray-900 rounded-lg">
          <h1 className="text-4xl font-bold mb-4">Flight Simulator</h1>
          <p className="text-lg mb-4">
            Controls: WASD to fly, Shift to boost, Ctrl to slow down
          </p>
          <p className="text-md mb-6">
            Avoid buildings and land on the green zones!
          </p>
          
          {/* Arabic Mode Toggle */}
          <div className="mb-6">
            <button
              onClick={toggleArabicMode}
              className={`px-4 py-2 rounded-lg font-semibold mr-2 ${
                arabicMode 
                  ? 'bg-red-600 hover:bg-red-700 text-white' 
                  : 'bg-gray-600 hover:bg-gray-700 text-white'
              }`}
            >
              {arabicMode ? 'Arabic Mode: ON' : 'Arabic Mode: OFF'}
            </button>
            {arabicMode && (
              <div className="text-sm text-red-400 mt-2">
                ⚠️ EXTREME DIFFICULTY: Moving buildings, changing targets, limited fuel!
              </div>
            )}
          </div>
          
          <button
            onClick={startGame}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-xl font-semibold"
          >
            Start Game
          </button>
        </div>
      </div>
    );
  }

  if (gamePhase === "crashed") {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-red-900 bg-opacity-80 text-white z-50">
        <div className="text-center p-8 bg-gray-900 rounded-lg">
          <h1 className="text-4xl font-bold mb-4 text-red-400">CRASHED!</h1>
          <p className="text-lg mb-6">
            You hit a building and crashed!
          </p>
          <p className="text-md mb-6">
            Press R to respawn at the takeoff area
          </p>
          <div className="text-sm opacity-75">
            Press R to continue
          </div>
        </div>
      </div>
    );
  }

  if (gamePhase === "won") {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-green-900 bg-opacity-80 text-white z-50">
        <div className="text-center p-8 bg-gray-900 rounded-lg">
          <h1 className="text-4xl font-bold mb-4 text-green-400">MISSION COMPLETE!</h1>
          <p className="text-lg mb-6">
            You successfully landed in the designated zone!
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg text-xl font-semibold"
          >
            Play Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-4 left-4 right-4 pointer-events-none text-white z-40">
      {/* Top HUD */}
      <div className="flex justify-between items-start">
        {/* Left side - Flight instruments */}
        <div className="bg-black bg-opacity-60 p-4 rounded-lg">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">SPEED:</span>
              <div className="w-24 h-2 bg-gray-700 rounded">
                <div 
                  className="h-full bg-blue-400 rounded"
                  style={{ width: `${(speed / 0.8) * 100}%` }}
                />
              </div>
              <span className="text-sm">{Math.round(speed * 100)} km/h</span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">ALT:</span>
              <div className="w-24 h-2 bg-gray-700 rounded">
                <div 
                  className="h-full bg-green-400 rounded"
                  style={{ width: `${Math.min((altitude / 50) * 100, 100)}%` }}
                />
              </div>
              <span className="text-sm">{Math.round(altitude)}m</span>
            </div>
            
            {showFuel && (
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold">FUEL:</span>
                <div className="w-24 h-2 bg-gray-700 rounded">
                  <div 
                    className={`h-full rounded ${fuel > 20 ? 'bg-yellow-400' : 'bg-red-400'}`}
                    style={{ width: `${fuel}%` }}
                  />
                </div>
                <span className="text-sm">{Math.round(fuel)}%</span>
              </div>
            )}
          </div>
        </div>

        {/* Right side - Mission info */}
        <div className="bg-black bg-opacity-60 p-4 rounded-lg text-right">
          <div className="text-sm">
            <div className="font-semibold">MISSION:</div>
            <div>Land on airborne target</div>
            <div className="text-xs opacity-75 mt-1">
              {arabicMode ? 'Difficulty: ARABIC (EXTREME)' : 'Difficulty: HARD'}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom controls */}
      <div className="fixed bottom-4 left-4 bg-black bg-opacity-60 p-3 rounded-lg text-xs">
        <div className="grid grid-cols-2 gap-x-4 gap-y-1">
          <span>W/S: Pitch</span>
          <span>A/D: Turn</span>
          <span>Shift: Boost</span>
          <span>Ctrl: Slow</span>
        </div>
        <button
          onClick={toggleFuelDisplay}
          className="mt-2 px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs pointer-events-auto"
        >
          {showFuel ? 'Hide' : 'Show'} Fuel
        </button>
      </div>

      {/* Warning messages */}
      {fuel < 20 && fuel > 0 && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-red-600 p-3 rounded-lg animate-pulse">
          <div className="font-bold">LOW FUEL WARNING!</div>
        </div>
      )}

      {fuel <= 0 && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-red-800 p-3 rounded-lg">
          <div className="font-bold">OUT OF FUEL!</div>
          <div className="text-sm">Engine stopped</div>
        </div>
      )}
    </div>
  );
}
