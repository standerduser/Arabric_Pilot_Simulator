import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface ExplosionEffectProps {
  position: THREE.Vector3;
  onComplete: () => void;
}

export function ExplosionEffect({ position, onComplete }: ExplosionEffectProps) {
  const groupRef = useRef<THREE.Group>(null);
  const particlesRef = useRef<THREE.Points[]>([]);
  const startTime = useRef(Date.now());

  useEffect(() => {
    console.log("Explosion effect started at position:", position);
    
    // Auto-complete after 3 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  useFrame(() => {
    if (!groupRef.current) return;

    const elapsed = (Date.now() - startTime.current) / 1000;
    const progress = elapsed / 3; // 3 second duration

    // Animate particles
    particlesRef.current.forEach((particles, index) => {
      if (particles) {
        const positions = particles.geometry.attributes.position.array as Float32Array;
        const velocities = (particles as any).velocities;
        
        for (let i = 0; i < positions.length; i += 3) {
          positions[i] += velocities[i] * 0.1; // x
          positions[i + 1] += velocities[i + 1] * 0.1; // y
          positions[i + 2] += velocities[i + 2] * 0.1; // z
          
          // Apply gravity to y
          velocities[i + 1] -= 0.02;
        }
        
        particles.geometry.attributes.position.needsUpdate = true;
        
        // Fade out
        if (particles.material instanceof THREE.PointsMaterial) {
          particles.material.opacity = Math.max(0, 1 - progress);
        }
      }
    });
  });

  // Create explosion particles
  const createParticles = (count: number, color: string, spread: number) => {
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Initial position (at explosion center)
      positions[i3] = position.x;
      positions[i3 + 1] = position.y;
      positions[i3 + 2] = position.z;
      
      // Random velocity
      velocities[i3] = (Math.random() - 0.5) * spread;
      velocities[i3 + 1] = Math.random() * spread * 0.5;
      velocities[i3 + 2] = (Math.random() - 0.5) * spread;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
      color,
      size: 0.5,
      transparent: true,
      opacity: 1,
    });

    const particles = new THREE.Points(geometry, material);
    (particles as any).velocities = velocities;
    
    return particles;
  };

  useEffect(() => {
    if (groupRef.current) {
      // Create different particle systems
      const fireParticles = createParticles(50, '#ff4500', 4);
      const smokeParticles = createParticles(30, '#333333', 2);
      const sparkParticles = createParticles(20, '#ffff00', 6);

      groupRef.current.add(fireParticles);
      groupRef.current.add(smokeParticles);
      groupRef.current.add(sparkParticles);

      particlesRef.current = [fireParticles, smokeParticles, sparkParticles];
    }
  }, []);

  return (
    <group ref={groupRef}>
      {/* Central explosion flash */}
      <mesh position={position.toArray()}>
        <sphereGeometry args={[2, 8, 8]} />
        <meshBasicMaterial color="#ff6600" transparent opacity={0.8} />
      </mesh>
      
      {/* Light flash */}
      <pointLight
        position={position.toArray()}
        color="#ff4500"
        intensity={3}
        distance={20}
      />
    </group>
  );
}
