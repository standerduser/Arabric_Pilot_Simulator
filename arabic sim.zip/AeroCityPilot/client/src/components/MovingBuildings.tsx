import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useFlightGame } from "../lib/stores/useFlightGame";

export function MovingBuildings() {
  const groupRef = useRef<THREE.Group>(null);
  const arabicMode = useFlightGame((state) => state.arabicMode);

  // Generate building data (memoized to prevent regeneration)
  const buildingData = useMemo(() => {
    const buildings = [];
    for (let x = -40; x <= 40; x += 20) {
      for (let z = -40; z <= 40; z += 20) {
        // Skip extended safe takeoff zone (longer runway)
        if (Math.abs(x) < 12 && z >= -20 && z <= 5) continue;
        
        const height = Math.random() * 15 + 10;
        const hue = 200 + Math.random() * 40;
        const lightness = 40 + Math.random() * 20;
        // Add movement properties for Arabic mode
        const moveSpeedX = (Math.random() - 0.5) * 0.2; // Random movement speed
        const moveSpeedZ = (Math.random() - 0.5) * 0.2;
        const moveRadiusX = Math.random() * 8 + 2; // Movement radius
        const moveRadiusZ = Math.random() * 8 + 2;
        
        buildings.push({ 
          baseX: x, 
          baseZ: z, 
          height, 
          color: `hsl(${hue}, 30%, ${lightness}%)`,
          moveSpeedX,
          moveSpeedZ,
          moveRadiusX,
          moveRadiusZ
        });
      }
    }
    return buildings;
  }, []);

  useFrame((state) => {
    if (!groupRef.current || !arabicMode) return;

    // Move buildings in Arabic mode
    const time = state.clock.elapsedTime;
    
    groupRef.current.children.forEach((building, index) => {
      if (building instanceof THREE.Group && buildingData[index]) {
        const data = buildingData[index];
        
        // Calculate new position using sinusoidal movement
        const newX = data.baseX + Math.sin(time * data.moveSpeedX + index) * data.moveRadiusX;
        const newZ = data.baseZ + Math.cos(time * data.moveSpeedZ + index) * data.moveRadiusZ;
        
        building.position.x = newX;
        building.position.z = newZ;
      }
    });
  });

  return (
    <group ref={groupRef}>
      {buildingData.map((building, index) => (
        <group key={index} position={[building.baseX, building.height / 2, building.baseZ]}>
          <mesh>
            <boxGeometry args={[8, building.height, 8]} />
            <meshLambertMaterial color={building.color} />
          </mesh>
          
          {/* Building windows */}
          {Array.from({ length: Math.floor(building.height / 3) }, (_, floor) => (
            <group key={floor} position={[0, -building.height / 2 + floor * 3 + 1.5, 0]}>
              {/* Front windows */}
              <mesh position={[0, 0, 4.01]}>
                <planeGeometry args={[6, 1]} />
                <meshLambertMaterial color="yellow" opacity={0.8} transparent />
              </mesh>
              {/* Back windows */}
              <mesh position={[0, 0, -4.01]} rotation={[0, Math.PI, 0]}>
                <planeGeometry args={[6, 1]} />
                <meshLambertMaterial color="yellow" opacity={0.8} transparent />
              </mesh>
              {/* Side windows */}
              <mesh position={[4.01, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
                <planeGeometry args={[6, 1]} />
                <meshLambertMaterial color="yellow" opacity={0.8} transparent />
              </mesh>
              <mesh position={[-4.01, 0, 0]} rotation={[0, -Math.PI / 2, 0]}>
                <planeGeometry args={[6, 1]} />
                <meshLambertMaterial color="yellow" opacity={0.8} transparent />
              </mesh>
            </group>
          ))}
        </group>
      ))}
    </group>
  );
}