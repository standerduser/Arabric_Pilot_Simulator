import { useRef, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useFlightGame } from "../lib/stores/useFlightGame";

export function GameCamera() {
  const { camera } = useThree();
  const airplanePosition = useFlightGame((state) => state.position);
  const airplaneRotation = useFlightGame((state) => state.rotation);
  const gamePhase = useFlightGame((state) => state.gamePhase);
  
  // Camera offset behind the airplane (positioned behind in local space)
  const cameraOffset = new THREE.Vector3(0, 4, -10);
  const targetOffset = new THREE.Vector3(0, 0, 3);

  useFrame(() => {
    if (gamePhase !== "playing") return;

    // Calculate camera position behind the airplane
    const airplaneMatrix = new THREE.Matrix4();
    airplaneMatrix.makeRotationFromEuler(airplaneRotation);
    
    // Transform the offset by airplane rotation
    const worldCameraOffset = cameraOffset.clone();
    worldCameraOffset.applyMatrix4(airplaneMatrix);
    
    const targetCameraPosition = airplanePosition.clone().add(worldCameraOffset);
    
    // Calculate look-at target (in front of airplane)
    const worldTargetOffset = targetOffset.clone();
    worldTargetOffset.applyMatrix4(airplaneMatrix);
    const lookAtTarget = airplanePosition.clone().add(worldTargetOffset);
    
    // Smooth camera movement with better interpolation
    camera.position.lerp(targetCameraPosition, 0.08);
    
    // Smooth camera rotation by using lookAt with interpolation
    const currentLookAt = new THREE.Vector3();
    camera.getWorldDirection(currentLookAt);
    currentLookAt.add(camera.position);
    currentLookAt.lerp(lookAtTarget, 0.1);
    camera.lookAt(currentLookAt);
    
    // Update camera
    camera.updateMatrixWorld();
  });

  useEffect(() => {
    // Set initial camera position behind spawn point
    camera.position.set(0, 6, -22);
    camera.lookAt(0, 2, -12);
  }, [camera]);

  return null;
}
