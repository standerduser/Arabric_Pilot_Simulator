import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import { KeyboardControls } from "@react-three/drei";
import "@fontsource/inter";

import { Airplane } from "./components/Airplane";
import { CityEnvironment } from "./components/CityEnvironment";
import { GameCamera } from "./components/GameCamera";
import { GameHUD } from "./components/GameHUD";
import { LandingZone } from "./components/LandingZone";
import { ExplosionEffect } from "./components/ExplosionEffect";
import { BuildingExplosion } from "./components/BuildingExplosion";
import { useFlightGame } from "./lib/stores/useFlightGame";
import { useAudio } from "./lib/stores/useAudio";

// Define control keys for the game
const controls = [
  { name: "forward", keys: ["KeyW"] },
  { name: "backward", keys: ["KeyS"] },
  { name: "left", keys: ["KeyA"] },
  { name: "right", keys: ["KeyD"] },
  { name: "boost", keys: ["ShiftLeft", "ShiftRight"] },
  { name: "slow", keys: ["ControlLeft", "ControlRight"] },
];

function App() {
  const { gamePhase, landingZones, position, buildingExplosions, crash, win, removeBuildingExplosion } = useFlightGame();
  const { playHit, playSuccess } = useAudio();

  const handleCrash = () => {
    playHit();
    crash();
  };

  const handleLanding = () => {
    playSuccess();
    win();
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <KeyboardControls map={controls}>
        {/* Game HUD - always visible */}
        <GameHUD />

        {/* 3D Scene - only when playing */}
        {(gamePhase === 'playing' || gamePhase === 'crashed') && (
          <Canvas
            shadows
            camera={{
              position: [0, 5, -10],
              fov: 75,
              near: 0.1,
              far: 1000
            }}
            gl={{
              antialias: true,
              powerPreference: "default"
            }}
          >
            {/* Sky background */}
            <color attach="background" args={["#87CEEB"]} />

            <Suspense fallback={null}>
              {/* Environment */}
              <CityEnvironment />

              {/* Airplane */}
              <Airplane onCollision={handleCrash} />

              {/* Landing zones */}
              {landingZones.map((zone, index) => (
                <LandingZone
                  key={index}
                  position={zone}
                  index={index}
                  onLanding={handleLanding}
                />
              ))}

              {/* Explosion effect when crashed */}
              {gamePhase === 'crashed' && (
                <ExplosionEffect
                  position={position}
                  onComplete={() => {
                    // Explosion animation complete
                    console.log("Explosion animation completed");
                  }}
                />
              )}
              
              {/* Building explosions */}
              {buildingExplosions.map((explosion) => (
                <BuildingExplosion
                  key={explosion.id}
                  position={explosion.position}
                  onComplete={() => removeBuildingExplosion(explosion.id)}
                />
              ))}

              {/* Camera controller */}
              <GameCamera />
            </Suspense>
          </Canvas>
        )}
      </KeyboardControls>
    </div>
  );
}

export default App;
